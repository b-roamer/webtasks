function highlight(this)
{
    if (this.checked)
    {
        this.classList.add("highlighted")
    }
    else
    {
        this.classList.remove("highlighted")
    }
}

//это жай проверял не обращай внимания на this

const checkbox = document.querySelectorAll(".checkbox_btn");